//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DDCBlockAccess.rc
//
#define IDD_DDCBlockAccess_DIALOG       102
#define IDR_MAINFRAME                   130
#define IDC_EDIT_CURRENT                1000
#define IDC_EDIT_MAX                    1001
#define IDC_EDIT_RAWEDID                1002
#define IDC_BUTTON_SET                  1003
#define IDC_BUTTON_GET                  1004
#define IDC_COMBO_DEVICENAME            1005
#define IDC_EDIT_AINDEX                 1005
#define IDC_EDIT_ANAME                  1005
#define IDC_COMBO_VCPCODE               1006
#define IDC_COMBO2                      1007
#define IDC_COMBO_DISPLAYINDEX          1007
#define IDC_COMBO_DRIVERINDEX           1008
#define IDC_EDIT_DNAME                  1009
#define IDC_EDIT_TEXTEDID               1010
#define IDC_EDIT_DNAME2                 1011
#define IDC_EDIT_MONNAME                1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
